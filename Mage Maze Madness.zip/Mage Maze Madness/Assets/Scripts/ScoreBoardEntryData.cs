﻿

using System;

namespace MageMadness.Scoreboards
{
    [Serializable]

    public struct ScoreboardEntryData
    {
        public string entryName;
        public int entryScore;
    }
}